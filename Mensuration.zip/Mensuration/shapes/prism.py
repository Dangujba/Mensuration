import math

def volume(base_area, height):
    return base_area * height

def surface_area(base_area, perimeter, height):
    return 2 * base_area + perimeter * height
